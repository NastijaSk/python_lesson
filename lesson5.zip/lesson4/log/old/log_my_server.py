'''
Logging
'''
import logging
import sys
sys.path.append('../')

logging.basicConfig(
    filename='my_server.log',
    format='%(asctime)-30s %(levelname)-15s %(module)-15s %(message)s',
    level=logging.DEBUG
)

LOG = logging.getLogger('app.basic')

if __name__=='__main__':
    LOG.debug('Отладка')