'''
Logging
'''
import logging
import sys
import os
from logging import handlers
from common.my_variable import LOGGING_LEVEL
sys.path.append('../')

SERVER_FORMAT = logging.Formatter('%(asctime)-30s %(levelname)-15s %(module)-15s %(message)s')
PATH = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(PATH, 'my_server_log.log')

print(PATH)
# STREAM_HANDLER = logging.StreamHandler(sys.stderr)
# STREAM_HANDLER.setFormatter(SERVER_FORMAT)
# STREAM_HANDLER.setLevel(logging.INFO)
LOG_FILE = handlers.TimedRotatingFileHandler(PATH, encoding='utf8', interval=1, when='M')
LOG_FILE.setFormatter(SERVER_FORMAT)

LOGGER = logging.getLogger('server')
# LOGGER.addHandler(STREAM_HANDLER)
LOGGER.addHandler(LOG_FILE)
LOGGER.setLevel(LOGGING_LEVEL)


if __name__ == '__main__':
    pass
