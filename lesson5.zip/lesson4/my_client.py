# coding: utf-8
"""Программа- мой клиент"""

import sys
import json
import socket
import time
from common.my_variable import ACTION, PRESENCE, TIME, USER, ACCOUNT_NAME, \
    DEFAULT_IP_ADDRESS, DEFAULT_PORT, LOGIN, PASSWORD, \
    AUTORISATION, TYPE, LOG_PASSW
from common.utils import get_message, send_message
import log.config_my_client_log
import logging

LOGGER_CLIENT = logging.getLogger('client_log')

def process_ans(message):
    '''
    Функция разбирает ответ сервера
    :param message:
    :return:
    '''
    # print(message)
    LOGGER_CLIENT.info('Клиент получил ответ от сервера: {}'.format(message))
    if LOG_PASSW in message:
        if message[LOG_PASSW] == 'yes':
            LOGGER_CLIENT.info('Получен положительный ответ авторизации')
            return '200 : autorisation'
    LOGGER_CLIENT.error('Ошибка авторизации')
    raise ValueError


def create_autorisation(login='not', passw='not'):
    ''' Функция авторизации
    :param login: логин
    :param passw: пароль
    :return: словарь с информацией об авторизации
    '''
    out = {
        ACTION: AUTORISATION,
        TIME: time.time(),
        TYPE: 'connect',
        USER: {
            LOGIN: login,
            PASSWORD: passw}
    }
    LOGGER_CLIENT.info('Сформирован запрос авторизации клиентом')
    return out


def create_presence(account_name='Guest'):
    '''
    Функция генерирует запрос о присутствии клиента
    :param account_name:
    :return:
    '''
    out = {
        ACTION: PRESENCE,
        TIME: time.time(),
        USER: {
            ACCOUNT_NAME: account_name
        }
    }
    LOGGER_CLIENT.info('Сформировано сообщение от клиента к серверу')
    return out


def main():
    '''
    Главная функция
    :return:
    '''
    # print('__main__')
    '''Загружаем параметы коммандной строки'''
    try:
        server_addr = sys.argv[1]
        server_port = int(sys.argv[2])
        print(server_addr, server_port)
        LOGGER_CLIENT.info('Параметры подключения: {}, {}'.format(server_addr, server_port))
        if server_port < 1024 or server_port > 65535:
            LOGGER_CLIENT.error('Недопустимый порт: {}'.format(server_port))
            raise ValueError
    except IndexError:
        server_addr = DEFAULT_IP_ADDRESS
        server_port = DEFAULT_PORT
        LOGGER_CLIENT.info('Параметры подключения default: {}, {}'.format(server_addr, server_port))
        # print(server_addr, server_port)
    except ValueError:
        LOGGER_CLIENT.error('Недопустимый порт: {}'.format(server_port))
        # print(
            # 'В качестве порта может быть указано только число в диапазоне от 1024 до 65535.')
        sys.exit(1)

    # print('клиент')
    sok = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sok.connect((server_addr, server_port))
    message_to_server = create_autorisation('admin', '1234567890')
    LOGGER_CLIENT.info('Сформировано сообщение от клиента к серверу в main(): {}'.format(message_to_server))
    # print('message_to_server', message_to_server)
    send_message(sok, message_to_server)
    LOGGER_CLIENT.info('Сообщение кодировано')

    try:
        answer = process_ans(get_message(sok))
        LOGGER_CLIENT.info('Сообщение декодировано')
        # print('answer', answer)
    except(ValueError, json.JSONDecodeError):
        LOGGER_CLIENT.error('Не удалось декодировать сообщение сервера')
        # print('Не удалось декодировать сообщение сервера.')

if __name__ == '__main__':
    main()
