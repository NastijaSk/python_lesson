#coding:utf-8
"""Константы"""

# Порт поумолчанию для сетевого ваимодействия
DEFAULT_PORT = 7788
# IP адрес по умолчанию для подключения клиента
DEFAULT_IP_ADDRESS = '127.0.0.1'
# Максимальная очередь подключений
MAX_QUERY = 10
# Максимальная длинна сообщения в байтах
MAX_PACKAGE_LENGTH = 1024
# Кодировка проекта
ENCODING = 'utf-8'

# Прококол JIM основные ключи:
ACTION = 'action'
AUTORISATION = 'autorisation'
TIME = 'time'
USER = 'user'
ACCOUNT_NAME = 'account_name'

LOGIN = 'login'
PASSWORD = 'password'
TYPE = 'connect'

# Прочие ключи, используемые в протоколе
PRESENCE = 'presence'
LOG_PASSW = 'log_passw'
RESPONSE = 'response'
ERROR = 'error'
RESPONDEFAULT_IP_ADDRESSSE = 'respondefault_ip_addressse'

LOGGING_LEVEL = 'DEBUG'
LOGGING_LEVEL_CLIENTS = 'DEBUG'