'''
Logging
'''

import logging
import sys
import os
from common.my_variable import LOGGING_LEVEL_CLIENTS

sys.path.append('../')

logging.basicConfig(
    filename='log/my_client_log.log',
    format='%(asctime)-30s %(levelname)-15s %(module)-15s %(message)s',
    level=LOGGING_LEVEL_CLIENTS
)

LOGGER_CLIENTS = logging.getLogger('client_log')

if __name__=='__main__':
    LOGGER_CLIENTS.debug('Отладка')
