# coding:utf-8

"""Программа-мой сервер"""

import socket
import sys
import json
from common.my_variable import USER, ERROR, DEFAULT_PORT, \
    LOG_PASSW, RESPONDEFAULT_IP_ADDRESSSE, MAX_QUERY, LOGIN, PASSWORD
from common.utils import get_message, send_message
import log.config_my_server_log
import logging

LOGGER = logging.getLogger('server')

def process_client_message(message):
    '''
    Обработчик сообщений от клиентов, принимает словарь -
    сообщение от клиента, проверяет корректность,
    возвращает словарь-ответ для клиента

    :param message:
    :return:
    '''
    LOGGER.info('Сообщение от клиента: {}' .format(message))
    if message[USER][LOGIN] == 'admin' and message[USER][PASSWORD] == '1234567890':
        # print({LOG_PASSW: 'yes'})
        inf = 'Клиент прошел авторизацию: {}'.format({LOG_PASSW: 'yes'})
        LOGGER.info(inf)
        return {LOG_PASSW: 'yes'}
    LOGGER.warning('Клиенту отказано в авторизации')
    return {
        RESPONDEFAULT_IP_ADDRESSSE: 402,
        ERROR: 'Invalid login/password'
    }


def main():
    '''
    Загрузка параметров командной строки, если нет параметров, то задаём значения по умоланию.
    Сначала обрабатываем порт:
    server.py -p 8888 -a 127.0.0.1
    :return:
    '''
    print('my_server')
    print(sys.argv)
    try:
        if '-p' in sys.argv:
            listen_port = int(sys.argv[sys.argv.index('-p') + 1])
            print(listen_port)
            LOGGER.info('Клиент подключается по порту: {}'.format(listen_port))

        else:
            listen_port = DEFAULT_PORT
            LOGGER.info('Клиент подключается по дефолтному порту: {}'.format(listen_port))
        if listen_port < 1024 or listen_port > 65535:
            LOGGER.error('Недопустимый порт')
            raise ValueError
    except IndexError:
        print('После параметра -\'p\' необходимо указать номер порта.')
        LOGGER.error('Не указан порт')
        sys.exit(1)
    except ValueError:
        print(
            'В качастве порта может быть указано только число в диапазоне от 1024 до 65535.')
        sys.exit(1)

    # Затем загружаем какой адрес слушать
    # print('ждем клиентов')
    LOGGER.debug('Сервер готов, ждет клиентов')
    try:
        if '-a' in sys.argv:
            listen_address = sys.argv[sys.argv.index('-a') + 1]
        else:
            listen_address = ''

    except IndexError:
        print(
            'После параметра \'a\'- необходимо указать адрес, который будет слушать сервер.')
        LOGGER.error('Не указан адрес')
        sys.exit(1)

    # Готовим сокет

    sok = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sok.bind((listen_address, listen_port))

    # print(sok)
    LOGGER.info('создан сокет: {}'.format(sok))
    # Слушаем порт

    sok.listen(MAX_QUERY)

    while True:
        client, client_address = sok.accept()
        LOGGER.info('Подключился клиент: {}'.format(client))
        # print(client)

        try:
            message_from_cient = get_message(client)
            # print(message_from_cient)
            LOGGER.info('Сообщение от клиента в main(): {}'.format(message_from_cient))
            response = process_client_message(message_from_cient)
            LOGGER.info('Сформирован ответ клиенту {}'.format(response))
            send_message(client, response)
            LOGGER.info('Ответ отправлен, соединение закрывается')
            client.close()
        except (ValueError, json.JSONDecodeError):
            # print('Принято некорретное сообщение от клиента.')
            LOGGER.error('Принято некорретное сообщение от клиента')
            client.close()


if __name__ == '__main__':
    main()
