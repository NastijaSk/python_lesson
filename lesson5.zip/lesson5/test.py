import unittest

class TestSumKV(unittest.TestCase):
    def testequal(self):
        self.assertEqual(1, 1)


if __name__ == '__main__':
    unittest.main()