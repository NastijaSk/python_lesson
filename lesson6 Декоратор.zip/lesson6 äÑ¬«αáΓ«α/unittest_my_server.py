#coding:utf-8

'''
Test My Server
'''

import unittest
from my_server import process_client_message
from common.my_variable import LOG_PASSW, RESPONDEFAULT_IP_ADDRESSSE, ERROR

class TestMyServer(unittest.TestCase):
    '''
    Class тестирования сервера
    '''
    true_answ = {LOG_PASSW: 'yes'}
    err_answ = {
        RESPONDEFAULT_IP_ADDRESSSE: 402,
        ERROR: 'Invalid login/password'
        }


    def test_true_login_passw(self):
        '''
        Тест верный логин, пароль
        :return:
        '''
        self.assertEquals(process_client_message(
            {'user':{'login': 'admin', 'password': '1234567890'}}), self.true_answ)

    def test_err_login_passw(self):
        '''
        Hеверный логин, пароль
        :return:
        '''
        self.assertNotEquals(process_client_message(
            {'user':{'login': 'not', 'password': '1234567890'}}), self.true_answ)

    def test_err_login_passw_2(self):
        '''
        Аналогично предыдущему тесту, но с другим assert
        :return:
        '''
        self.assertEquals(process_client_message(
            {'user':{'login': 'not', 'password': '1234567890'}}), self.err_answ)

    def test_return_dict(self):
        '''
        Проверка, какой тип возвращает функция
        :return:
        '''
        self.assertIsInstance(process_client_message(
            {'user':{'login': 'not', 'password': '1234567890'}}), dict, msg='Return not dict')

if __name__ == '__main__':
    unittest.main()
