#coding: utf-8
''' My Test Clients '''
import unittest
from my_client import process_ans, create_autorisation, create_presence
from common.my_variable import ACTION, TIME, TYPE, USER, LOGIN, PASSWORD, AUTORISATION, PRESENCE, \
    ACCOUNT_NAME


class TestMyClient(unittest.TestCase):
    '''
    class for Unittest
    '''

    def test_process_ans(self):
        '''
        :return:
        '''
        self.assertEquals(process_ans({'log_passw': 'yes'}), '200 : autorisation')

    def test_raise_process_ans(self):
        '''
        тест появления raise
        :return:
        '''
        with self.assertRaises(ValueError):
            process_ans({'log_passw': 'no'})


    def test_autorisation(self):
        '''
        Авторизация
        :return:
        '''
        test = create_autorisation('123', 'p123')
        test[TIME] = 1.1
        out_true = {
            ACTION: AUTORISATION,
            TIME: 1.1,
            TYPE: 'connect',
            USER: {
                LOGIN: '123',
                PASSWORD: 'p123'}}

        self.assertEquals(test, out_true)


    def test_return_autorisation(self):
        '''
        Авторизация возвращает словарь
        :return:
        '''
        test = create_autorisation
        self.assertIsInstance(test(), dict, msg='Not dict')


    def test_presence(self):
        '''
        Тест функции присутсвия
        :return:
        '''
        test = create_presence('Test')
        test[TIME] = 1.1
        out = {
            ACTION: PRESENCE,
            TIME: 1.1,
            USER: {
                ACCOUNT_NAME: 'Test'
                }
            }
        self.assertEquals(test, out)

    def test_user_in(self):
        '''
        Тест наличия ключа USER
        :return:
        '''
        test = create_presence('Test')
        self.assertIn('user', test.keys())

    def test_time_in(self):
        '''
        Тест наличия ключа TIME
        :return:
        '''
        test = create_presence('Test')
        self.assertIn('time', test.keys())

    def test_account_name_in_user(self):
        '''
        Тест наличия ключа ACCOUNT_NAME в USER
        :return:
        '''
        test = create_presence('Test')
        self.assertIn('account_name', test['user'].keys())

if __name__ == '__main__':
    unittest.main()
