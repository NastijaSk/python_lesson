import sys
import logging
import log.config_my_client_log
import log.config_my_server_log

if sys.argv[0].find('client') == -1:
    # сервер
    LOGGER = logging.getLogger('server')
else:
    # клиент
    LOGGER = logging.getLogger('client_log')

def log(func_log):
    def log_saver(*args, **kwargs):
        ret_log= func_log(*args, **kwargs)
        LOGGER.debug('вызов функции {} с параметрами {}, {} из модуля {}'.format(func_log.__name__, args, kwargs, func_log.__module__))

        return ret_log
    return log_saver